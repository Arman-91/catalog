dokanWebpack([4],{

/***/ 208:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__wordpress_hooks__ = __webpack_require__(39);

dokan.wpPackages = {
  hooks: Object(__WEBPACK_IMPORTED_MODULE_0__wordpress_hooks__["a" /* createHooks */])()
};

/***/ })

},[208]);